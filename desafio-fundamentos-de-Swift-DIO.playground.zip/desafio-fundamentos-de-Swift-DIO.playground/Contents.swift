let firstName = "Steve"
var lastName: String? = "Jobs"

print("\(firstName) \(lastName ?? "Wozniak")")

var last = lastName

if last == String(lastName!) {
    print ("\(firstName) \(last ?? "Wozniak")")
}
